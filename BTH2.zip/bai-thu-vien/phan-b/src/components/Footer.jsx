export default function Footer(){return <footer className="footer">Bài thực hành React cơ bản</footer>;}
